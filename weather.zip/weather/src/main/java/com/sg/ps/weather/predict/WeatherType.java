package com.sg.ps.weather.predict;

public enum WeatherType {

	Thunderstorm, Drizzle, Rain, Snow, Atmosphere, Clear, Clouds
}
